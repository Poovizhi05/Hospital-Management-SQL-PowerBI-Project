CREATE DATABASE HOSPITAL_DB;
USE HOSPITAL_DB;



CREATE TABLE Patients (
Patient_ID INT PRIMARY KEY AUTO_INCREMENT,
Firstname TEXT ,
Lastname TEXT,
DOB DATE,
Gender VARCHAR(10),
Contact_Number VARCHAR(15),
Address TEXT,
Registration_Date DATE 
);

INSERT INTO Patients (Firstname, Lastname, DOB, Gender, Contact_Number, Address, Registration_Date)
VALUES 
('John', 'Doe', '1985-06-15', 'Male', '9876543210', '123 Elm Street, Springfield', '2024-12-01'),
('Emily', 'Clark', '1990-09-22', 'Female', '9123456789', '45 Oak Avenue, Riverdale', '2025-01-10'),
('Michael', 'Smith', '1978-03-05', 'Male', '9012345678', '78 Pine Road, Hillview', '2025-02-17'),
('Sophia', 'Lopez', '2000-11-30', 'Female', '9988776655', '33 Maple Street, Lakeside', '2025-03-05'),
('Amit', 'Sharma', '1988-07-12', 'Male', '9345678901', '88 Neem Lane, New Delhi', '2025-04-01');





USE HOSPITAL_DB;
CREATE TABLE Doctors (
    Doctor_ID INT PRIMARY KEY AUTO_INCREMENT,
    Firstname VARCHAR(50), 
    Lastname VARCHAR(50),
    Specialization VARCHAR(100),
    Contact_Number VARCHAR(15),
    Email VARCHAR(30),
    Created_At TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO Doctors (Firstname, Lastname, Specialization, Contact_Number, Email)
VALUES 
('Rajiv', 'Mehra', 'Cardiologist', '9876543211', 'rajiv.mehra@hospital.com'),
('Anita', 'Desai', 'Neurologist', '9123456790', 'anita.desai@hospital.com'),
('David', 'Brown', 'General Physician', '9001234567', 'david.brown@hospital.com'),
('Sneha', 'Patel', 'Pediatrician', '9988776644', 'sneha.patel@hospital.com'),
('Arun', 'Kumar', 'Orthopedic Surgeon', '9345678912', 'arun.kumar@hospital.com');


USE HOSPITAL_DB;
CREATE TABLE Appointments (
    Appointment_ID INT PRIMARY KEY AUTO_INCREMENT,
    Patient_ID INT, 
    Doctor_ID INT,
    Appointment_Date Date,
    Purpose TEXT,
    Status ENUM ('Scheduled' , 'Completed' , 'Cancelled'),
    Created_At TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (Patient_ID) REFERENCES Patients(Patient_ID),
    FOREIGN KEY (Doctor_ID) REFERENCES Doctors(Doctor_ID)
);

INSERT INTO Appointments (Patient_ID, Doctor_ID, Appointment_Date, Purpose, Status)
VALUES 
(1, 2, '2025-04-10', 'Headache and dizziness', 'Completed'),
(2, 1, '2025-04-12', 'Routine heart checkup', 'Scheduled'),
(3, 3, '2025-04-15', 'Flu symptoms', 'Completed'),
(4, 4, '2025-04-17', 'Child vaccination', 'Scheduled'),
(5, 5, '2025-04-18', 'Knee pain', 'Cancelled');


USE HOSPITAL_DB;
CREATE TABLE Treatments (
	Treatment_ID INT PRIMARY KEY AUTO_INCREMENT,
    Appointment_ID INT, 
    Diagnosis TEXT,
    Prescription TEXT,
    Treatment_Date DATE,
    Created_At TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    Updated_At TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY(Appointment_ID) REFERENCES Appointments(Appointment_ID)
);

INSERT INTO Treatments (Appointment_ID, Diagnosis, Prescription, Treatment_Date)
VALUES 
(1, 'Migraine with mild vertigo', 'Paracetamol 500mg twice daily for 5 days, Rest, Hydration', '2025-04-10'),
(2, 'Seasonal Influenza', 'Oseltamivir 75mg twice daily for 5 days, Bed rest, Fluids', '2025-04-15'),
(3, 'Hypertension (Routine Check)', 'Continue Amlodipine 5mg once daily, monitor BP weekly', '2025-04-12'),
(4, 'Routine Vaccination - DPT booster', 'Administered DPT booster dose, follow-up after 6 months', '2025-04-17'),
(5, 'Early stage arthritis (assessment pending)', 'Advised X-ray, temporary use of Ibuprofen 400mg if needed', '2025-04-18');

USE HOSPITAL_DB;

CREATE TABLE Bills (
    Bill_ID INT PRIMARY KEY AUTO_INCREMENT,
    Patient_ID INT,
    Amount DECIMAL(10,2),
    Status ENUM('Paid', 'Unpaid', 'Pending'),
    Billing_Date DATE,
    Due_Date DATE,
    Payment_Method ENUM('Cash', 'Card', 'UPI', 'Insurance'),
    Created_At TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(Patient_ID) REFERENCES Patients(Patient_ID)
);

INSERT INTO Bills (Patient_ID, Amount, Status, Billing_Date, Due_Date, Payment_Method)
VALUES
(1, 1500.00, 'Paid', '2025-04-01', '2025-04-10', 'Card'),
(2, 3200.50, 'Unpaid', '2025-04-05', '2025-04-15', 'UPI'),
(3, 450.75, 'Paid', '2025-04-07', '2025-04-12', 'Cash'),
(4, 2500.00, 'Pending', '2025-04-10', '2025-04-20', 'Insurance'),
(5, 1250.00, 'Unpaid', '2025-04-12', '2025-04-22', 'Card'),
(1, 980.00, 'Pending', '2025-04-15', '2025-04-25', 'UPI'),
(2, 300.00, 'Unpaid', '2025-04-18', '2025-04-28', 'Cash');



	


USE HOSPITAL_DB; 
DELIMITER $$

CREATE PROCEDURE GetPatientBills(IN in_patient_id INT)
BEGIN
    SELECT 
        Bill_ID,
        Amount,
        Status,
        Billing_Date,
        Due_Date
    FROM Bills
    WHERE Patient_ID = in_patient_id;
END $$

DELIMITER ;

 CALL GetPatientBills(4);

-- View patient appointments with doctor details --

SELECT 
    a.Appointment_ID,
    p.Firstname AS Patient_Name,
    d.Firstname AS Doctor_Name,
    a.Appointment_Date,
    a.Purpose,
    a.Status
FROM Appointments a
JOIN Patients p ON a.Patient_ID = p.Patient_ID
JOIN Doctors d ON a.Doctor_ID = d.Doctor_ID;


-- View for recent treatments--

CREATE VIEW Recent_Treatments AS
SELECT 
    t.Treatment_ID,
    p.Firstname AS Patient_Name,
    d.Firstname AS Doctor_Name,
    t.Diagnosis,
    t.Treatment_Date
FROM Treatments t
JOIN Appointments a ON t.Appointment_ID = a.Appointment_ID
JOIN Patients p ON a.Patient_ID = p.Patient_ID
JOIN Doctors d ON a.Doctor_ID = d.Doctor_ID
ORDER BY t.Treatment_Date DESC;

SELECT * FROM Recent_Treatments;

USE HOSPITAL_DB;
CREATE TABLE Logs (
    Log_ID INT PRIMARY KEY AUTO_INCREMENT,
    Action VARCHAR(100),
    Table_Affected VARCHAR(50),
    Record_ID INT,
    Action_Timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    Performed_By VARCHAR(50)
);

DELIMITER $$  -- Change delimiter to $$ for the procedure

SELECT * FROM Logs;


DELIMITER $$

CREATE PROCEDURE UpdateBillStatus (
    IN billId INT,
    IN newStatus ENUM('Paid', 'Unpaid', 'Pending')
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SELECT '❌ Error occurred during update' AS ErrorMessage;
    END;

    START TRANSACTION;
-- Try to update the bill
    UPDATE Bills
    SET Status = newStatus
    WHERE Bill_ID = billId;

    IF ROW_COUNT() = 0 THEN
        ROLLBACK;
        SELECT '⚠️ Bill not found' AS ErrorMessage;
    ELSE
        -- Log the update
        INSERT INTO Logs (Action, Table_Affected, Record_ID, Performed_By)
        VALUES ('Bill Status Updated', 'Bills', billId, 'Admin');

        COMMIT;
        SELECT '✅ Bill status updated successfully' AS SuccessMessage;
    END IF;
END $$

DELIMITER ;

SELECT * FROM Bills;
CALL UpdateBillStatus(7, 'Paid');




USE HOSPITAL_DB;
DELIMITER //

CREATE TRIGGER update_bill_status_after_treatment
AFTER UPDATE ON Treatments
FOR EACH ROW
BEGIN
    IF NEW.Treatment_Date IS NOT NULL THEN
        UPDATE Bills
        SET 
            status = 'Paid',
            Billing_Date = CURDATE()
        WHERE Patient_ID = (
            SELECT a.Patient_ID
            FROM Appointments a
            WHERE a.Appointment_ID = NEW.Appointment_ID
        );
    END IF;
END;
//

DELIMITER ;

-- Sample update we have done to verify trigger works as expected --

UPDATE Treatments t
JOIN Appointments a ON t.Appointment_ID = a.Appointment_ID
SET t.Treatment_Date = CURDATE()
WHERE a.Patient_ID = 2;

-- Query to check no of patients treated and revenue made by doctors--

SELECT 
    d.Firstname, 
    COUNT(DISTINCT a.Patient_ID) AS patients_treated, 
    SUM(b.Amount) AS total_revenue
FROM Doctors d
JOIN Appointments a ON d.Doctor_ID = a.Doctor_ID
JOIN Treatments t ON a.Appointment_ID = t.Appointment_ID
JOIN Bills b ON a.Patient_ID = b.Patient_ID
WHERE t.Treatment_Date IS NOT NULL AND b.status = 'Paid'
GROUP BY d.Firstname;

SELECT * from Doctors;

-- Step 1: Create the role if it doesn't exist
CREATE ROLE IF NOT EXISTS 'doctor';

-- Step 2: Grant necessary permissions to the role
GRANT SELECT, INSERT, UPDATE ON HOSPITAL_DB.Patients TO 'doctor';
GRANT SELECT ON HOSPITAL_DB.Doctors TO 'doctor';

-- Step 3: Create users and assign the role
CREATE USER IF NOT EXISTS 'rajiv'@'localhost' IDENTIFIED BY 'Rajiv@123';
GRANT 'doctor' TO 'rajiv'@'localhost';

CREATE USER IF NOT EXISTS 'anita'@'localhost' IDENTIFIED BY 'Anita@123';
GRANT 'doctor' TO 'anita'@'localhost';

CREATE USER IF NOT EXISTS 'david'@'localhost' IDENTIFIED BY 'David@123';
GRANT 'doctor' TO 'david'@'localhost';

CREATE USER IF NOT EXISTS 'sneha'@'localhost' IDENTIFIED BY 'Sneha@123';
GRANT 'doctor' TO 'sneha'@'localhost';

CREATE USER IF NOT EXISTS 'arun'@'localhost' IDENTIFIED BY 'Arun@123';
GRANT 'doctor' TO 'arun'@'localhost';
SHOW GRANTS FOR 'doctor';


SELECT user, host FROM mysql.user;
SELECT * FROM mysql.role_edges;


EXPLAIN SELECT * FROM Appointments a JOIN Patients p ON a.Patient_ID = p.Patient_ID;

CREATE INDEX idx_patient_id ON Appointments(Patient_ID);

SHOW INDEX FROM Appointments;

SELECT TABLE_NAME, INDEX_NAME, COLUMN_NAME, NON_UNIQUE
FROM information_schema.STATISTICS
WHERE TABLE_SCHEMA = 'HOSPITAL_DB';


EXPLAIN
SELECT p.Firstname AS Patient_Name, d.Firstname AS Doctor_Name, t.Diagnosis
FROM Patients p
JOIN Appointments a ON p.Patient_ID = a.Patient_ID
JOIN Treatments t ON a.Appointment_ID = t.Appointment_ID
JOIN Doctors d ON a.Doctor_ID = d.Doctor_ID;  


EXPLAIN
SELECT d.Specialization, COUNT(t.Treatment_ID) AS Total_Treatments
FROM Doctors d
JOIN Appointments a ON d.Doctor_ID = a.Doctor_ID
JOIN Treatments t ON a.Appointment_ID = t.Appointment_ID
GROUP BY d.Specialization;




ALTER TABLE Appointments
ADD CONSTRAINT unique_appointment UNIQUE (Patient_ID, Doctor_ID, Appointment_Date);

SELECT * FROM Appointments;

INSERT INTO Appointments (Patient_ID, Doctor_ID, Appointment_Date)
VALUES(1 , 2 , '2025-04-10');


USE HOSPITAL_DB;
SELECT * FROM Patients LIMIT 3;
SELECT * FROM Appointments LIMIT 3;
SELECT * FROM Bills LIMIT 3;




