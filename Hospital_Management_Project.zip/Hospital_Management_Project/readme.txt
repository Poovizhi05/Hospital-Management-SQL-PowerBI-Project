
# Hospital Management System - SQL + Power BI Project

## Overview
This project simulates a Hospital Management System where data is stored in a MySQL database hosted on AWS RDS.
Insights are visualized using Power BI.

## Components
- MySQL Database (AWS RDS)
- Power BI Dashboard
- SQL Scripts (Tables, Triggers, Views, Stored Procedures, etc.)
- Power BI Dashboard Screenshot (PNG)
- ER Diagram (PNG)
- PowerPoint Presentation (Project Summary)

## Setup Instructions

### 1. MySQL Setup on AWS
- Launch an RDS MySQL instance.
- Enable public access and configure the security group to allow inbound traffic on port 3306.
- Connect using MySQL Workbench or DBeaver.

### 2. Database Creation
- Execute the `hospital_management.sql` script provided in this package.
  ```
  mysql -u <username> -p -h <aws-endpoint> < hospital_management.sql
  ```

### 3. Power BI Setup
- Open the `.pbix` file in Power BI Desktop.
- Use "Transform Data" to update MySQL credentials (AWS host, username, password).
- Refresh the dashboard.

## Notes
- Triggers and Stored Procedures help automate billing updates and validations.
- Indexes and Role-based Access Control included for optimization and security.
- Power BI visuals include KPIs, filters, bar and pie charts.

## Author
Poovizhi Pandikumar
